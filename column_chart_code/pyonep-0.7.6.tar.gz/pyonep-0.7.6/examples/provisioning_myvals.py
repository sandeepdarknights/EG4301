# Vendor Token is available on the domain admin home page
vendortoken = '55f5e9bbb7f3e7898aae087b2dbb203eb39d936b'
# CIK of client to clone for model
clonecik = '2243029aec7f5c05830dd5ba31b6052c3935d5d0'  # Exosite Device
# CIK of parent of clonecik client. In the case of Portals,
# this is the CIK of the portal. It can be found in your portal under
# Account > Portals
# Look for: Key: 123abc...
portalcik = '7eeec3d7d8765fd0b5c2d951dc59f6f6bb16913f'
vendor = 'weaver'

