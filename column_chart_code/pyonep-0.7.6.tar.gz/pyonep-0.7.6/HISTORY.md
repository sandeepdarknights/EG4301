History
=======

0.7.6 (2013-8-18)
-----------------

- improved HTTP logging

0.7.5 (2013-8-12)
-----------------

- changed provisioning interface to manage by CIK 
  rather than vendor token by default
- fixed writegroup command
- added example code
- improved documentation 

0.7.4 (2013-7-22)
-----------------

- fixed support for python 2.5
- added example of using onep.py directly

0.7.3 (2013-7-19)
-----------------

- fixed issue with format in python 2.6
- fixed exception messages

0.7.2 (2013-7-19)
-----------------

- updated provisioning library for api change to use "meta" field
- updated provisioning library to use vendor token by default
- improved logging 
- fixed issue record offset is 0 in datastore
- reverted back to using distutils for python 2.6 support

0.7.1 (2013-7-18)
-----------------

- merge a few bug fixes from Exosite internal repo
- remove comment command
- fix multiple command example 

0.7.0 (2013-7-18)
-----------------

- renamed onepv1lib package to pyonep
- renamed onep_exceptions back to exceptions

0.6
---

- add usage command

0.5
---

- add support for https

0.4
---

- add support for sending multiple commands in a single request

0.3
---

- add provisioning library

0.2
---

- update example code

0.1
---

- initial version
